<?php 

/* Template Name: MC Home Page Template */ 

get_header(); // loads WP's header.php from your theme

?>

<div class="row main-tagline">
	<div class="col-lg-12">
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

			<!-- article -->
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

				<!-- This content is edited on the Page Section in Admin: -->
				<?php the_content(); ?>

			</article>
			<!-- /article -->

		<?php endwhile; ?>	

	<?php endif; ?>
</div><!-- /12 -->
</div><!-- /row -->



<div class="row home">

	<div class="col-5">
		<img src="https://picsum.photos/200" class="main-image">
	</div><!-- /5 -->


	<div class="col-7">

		<div class="row">

			<div class="col-lg-4">
				<img src="https://picsum.photos/200" class="main-image">
				<p>some text</p>
			</div><!-- /4 -->

			<div class="col-lg-4">
				<img src="https://picsum.photos/200" class="main-image">
				<p><a href="contact.html">contact</a></p>
			</div><!-- /4 -->

			<div class="col-lg-4">
				<img src="https://picsum.photos/200" class="main-image">
				<p>some text</p>
			</div><!-- /4 -->

			<div class="col-lg-4">
				<img src="https://picsum.photos/200" class="main-image">
				<p>some text</p>
			</div><!-- /4 -->

			<div class="col-lg-4">
				<img src="https://picsum.photos/200" class="main-image">
				<p>some text</p>
			</div><!-- /4 -->

			<div class="col-lg-4">
				<img src="https://picsum.photos/200" class="main-image">
				<p>some text</p>
			</div><!-- /4 -->

		</div><!-- /row -->

	</div><!-- /7 -->

</div><!-- /row -->



<div class="row ">

	<div class="col-lg-8">

		<div id="" class="row clearfix">

			<div class="col-md-6">
				<h2>Aliquam quis iaculis ligula, quis finibus tortor.</h2>
				<p>
					Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer egestas non felis id fermentum. Quisque mauris enim, rutrum id luctus vitae, imperdiet eu dolor. Maecenas interdum ac justo vitae luctus. Nunc convallis luctus convallis. Nunc nec augue non eros posuere fringilla. Integer turpis diam, efficitur ac scelerisque quis, aliquam sed neque.  
				</p>
			</div><!-- 6 -->

			<div class="col-md-6">
				<h2>Suspendisse lacus turpis, ullamcorper nec rhoncus ac, semper eget neque.</h2>
				<p>
					Duis suscipit finibus orci, id hendrerit urna ultricies sed. Mauris dolor lectus, blandit rhoncus risus eu, aliquam egestas metus. Quisque dignissim felis risus, eu gravida diam laoreet quis. Nulla vel ultricies odio. Praesent elementum nibh sed est dignissim finibus.
				</p>
			</div><!-- 6 -->

		</div><!-- row -->

	</div><!-- /8 -->


	<div class="col-lg-4">

		<?php // the recent posts query
		$the_query = new WP_Query( array(
			'posts_per_page' => 4,
		)); 
		?>

		<ul class="grid-holder">

			<?php if ( $the_query->have_posts() ) : ?>
				<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>

					<li>
						<?php 
						if ( has_post_thumbnail() ){
							the_post_thumbnail( 'main-image' );
						}

						else
						{
							echo '<img src="https://picsum.photos/200" class="main-image">';
						}  

						echo '<a href="';
						echo the_permalink();
						echo '">';
						echo '<h3>';
						echo get_the_title();
						echo '</h3>';
						echo '</a>';
						?>

					<?php endwhile; ?>
					<?php wp_reset_postdata(); ?>
				</li>
			<?php endif; ?>
		</ul>

	</div><!-- /4 -->

</div><!-- /row -->

</div><!--8 -->


</div><!-- row -->

<?php get_footer(); // loads WP's footer.php from your theme ?>
