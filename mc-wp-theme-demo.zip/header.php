<!DOCTYPE html>

<html <?php language_attributes(); ?> class="no-js">

<head>

  <meta charset="<?php bloginfo('charset'); ?>">

  <title>
    <?php echo get_the_title(); ?> | JohnSmith.com
  </title>

  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="<?php bloginfo('description'); ?>">

  <?php wp_head(); ?>

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">

  <link href="<?php echo get_template_directory_uri(); ?>/custom.css" rel="stylesheet">


</head>

<body <?php body_class(); ?>>

  <div class="header container logo">

    <img src="http://placehold.it/80x80" class="logo"  alt="my alt text">
    <h1>Your Company Name</h1>

    <?php
 
if ( is_active_sidebar( 'custom-header-widget' ) ) : ?>
    <div id="header-widget-area" class="chw-widget-area widget-area" role="complementary">
    <?php dynamic_sidebar( 'custom-header-widget' ); ?>
    </div>
     
<?php endif; ?>


  </div><!-- /header container -->
