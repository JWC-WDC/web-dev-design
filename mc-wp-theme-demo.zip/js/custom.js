if (typeof jQuery !== 'undefined') {

    // jQuery IS loaded, do stuff here.
    console.log('yep, you loaded jQ OK.');

}