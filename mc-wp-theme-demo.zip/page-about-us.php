<?php 

/* Template Name: MC Contact Page Template */ 

get_header(); // loads WP's header.php from your theme

?>



<div id="" class="row clearfix">

	<div class="col-md-12 ">
		<iframe src='https://cdn.knightlab.com/libs/timeline3/latest/embed/index.html?source=1uLWFWqWCFD0G_g7aCXVWMfCOREf-0omS6rXcJFyI0aA&font=Default&lang=en&initial_zoom=2&height=650' width='100%' height='650' webkitallowfullscreen mozallowfullscreen allowfullscreen frameborder='0'></iframe>
	</div><!-- 12 -->



	<div class="col-md-7">

		<h1><?php the_title(); ?></h1>

		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

			<?php the_content(); ?>

		<?php endwhile; ?>	

	<?php endif; ?>


	<?php // the recent posts query
	$the_query = new WP_Query( array(
		'posts_per_page' => 3,
	)); 
	?>

	<ul class="grid-holder">

		<?php if ( $the_query->have_posts() ) : ?>
			<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>

				<li>
					<?php 
					if ( has_post_thumbnail() ){
						the_post_thumbnail( 'main-image' );
					}

					else
					{
						echo '<img src="https://picsum.photos/200" class="main-image">';
					}  

					echo '<a href="';
					echo the_permalink();
					echo '">';
					echo '<h3>';
					echo get_the_title();
					echo '</h3>';
					echo '</a>';
					?>

				<?php endwhile; ?>
				<?php wp_reset_postdata(); ?>
			</li>
		<?php endif; ?>
	</ul>

</div><!-- 7 -->




<div class="col-md-5">

	<div id="" class="row clearfix">


		<div class="col-md-6">
			<h2>Aliquam quis iaculis ligula, quis finibus tortor.</h2>
			<p>
				Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer egestas non felis id fermentum. Quisque mauris enim, rutrum id luctus vitae, imperdiet eu dolor. Maecenas interdum ac justo vitae luctus. Nunc convallis luctus convallis. Nunc nec augue non eros posuere fringilla. Integer turpis diam, efficitur ac scelerisque quis, aliquam sed neque.  
			</p>
		</div><!-- 6 -->

		<div class="col-md-6">
			<h2>Suspendisse lacus turpis, ullamcorper nec rhoncus ac, semper eget neque.</h2>
			<p>
				Duis suscipit finibus orci, id hendrerit urna ultricies sed. Mauris dolor lectus, blandit rhoncus risus eu, aliquam egestas metus. Quisque dignissim felis risus, eu gravida diam laoreet quis. Nulla vel ultricies odio. Praesent elementum nibh sed est dignissim finibus.
			</p>
		</div><!-- 6 -->

	</div><!-- row -->

</div><!-- 5 -->
</div><!-- row -->

<?php get_footer(); // loads WP's footer.php from your theme ?>
